export function ErrorScreen() {
  return (
    <div className="flex flex-col items-center justify-center h-screen gap-4 relative z-10 px-6 text-center">
      <div className="text-5xl">⚠️</div>
      <h1 className="text-2xl font-bold bg-gradient-to-br from-nether-accent to-white bg-clip-text text-transparent">خطای اتصال</h1>
      <p className="text-nether-text-3 text-sm max-w-xs">نتونستم به سرور ربات وصل شم. مطمئن شو ربات روی هاست در حال اجراست.</p>
      <button className="btn btn-primary max-w-[200px]" onClick={() => location.reload()}>🔄 تلاش مجدد</button>
    </div>
  )
}
