const features = [
  { i: '🤖', t: 'هوش مصنوعی Agentic', d: 'جمع‌آوری خودکار اخبار، تولید پست با AI، انتشار هوشمند' },
  { i: '📡', t: 'منابع نامحدود', d: 'RSS، Reddit، وبسایت، mcpedl و Modrinth — کاملاً ایزوله' },
  { i: '🌐', t: 'آینه‌ی روبیکا', d: 'ربات تلگرام شما به‌عنوان آینه‌ی کامل در روبیکا هم کار می‌کنه' },
  { i: '🧠', t: 'یادگیری از بازخورد', d: 'ربات سلیقه‌ی شما رو یاد می‌گیره و اعمال می‌کنه' },
  { i: '🎮', t: 'ماد و Add-on', d: 'ساخت پست از Modrinth و mcpedl با فایل ماد' },
  { i: '🖼', t: 'واترمارک خودکار', d: 'اعمال واترمارک روی تمام تصاویر — تلگرام و روبیکا' },
]

export function AdScreen() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen px-6 py-8 relative z-10 text-center">
      <div className="text-5xl mb-2">🌋</div>
      <h1 className="text-2xl font-bold bg-gradient-to-br from-nether-accent to-white bg-clip-text text-transparent">Nether Agent</h1>
      <p className="text-nether-text-3 text-sm mt-1 mb-7">دستیار هوشمندِ خودکارِ مدیریت کانال</p>
      <div className="w-full max-w-md flex flex-col gap-3 mb-6">
        {features.map((f, i) => (
          <div key={i} className="flex gap-3 p-3.5 bg-nether-card rounded-2xl border border-nether-border text-right">
            <span className="text-2xl shrink-0">{f.i}</span>
            <div><h4 className="text-[13px] font-semibold mb-0.5">{f.t}</h4><p className="text-[11px] text-nether-text-3 leading-relaxed">{f.d}</p></div>
          </div>
        ))}
      </div>
      <p className="text-nether-text-3 text-sm mb-3">برای دسترسی به این قابلیت‌ها، اشتراک فعال لازمه.</p>
      <a href="https://t.me/NetherAgentBot" className="btn btn-primary max-w-[240px]">📱 دریافت اشتراک</a>
    </div>
  )
}
