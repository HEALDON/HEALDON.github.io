export function LoadingScreen() {
  return (
    <div className="flex flex-col items-center justify-center h-screen gap-3 relative z-10">
      <div className="w-10 h-10 border-2 border-nether-card border-t-nether-accent rounded-full animate-spin" />
      <p className="text-nether-text-3 text-[13px]">در حال اتصال...</p>
    </div>
  )
}
