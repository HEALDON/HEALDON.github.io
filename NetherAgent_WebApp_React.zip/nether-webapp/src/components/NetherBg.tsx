export function NetherBg() {
  return (
    <div className="fixed inset-0 z-0 overflow-hidden"
      style={{ background: 'radial-gradient(ellipse at 50% 100%, rgba(255,90,36,.04) 0%, transparent 60%), #080808' }}>
      <div className="absolute bottom-[-100px] left-1/2 -translate-x-1/2 w-[400px] h-[400px] rounded-full"
        style={{ background: 'radial-gradient(circle, rgba(255,90,36,.05) 0%, transparent 70%)' }} />
      {[0,1,2,3,4,5].map(i => (
        <div key={i} className="absolute w-0.5 h-0.5 bg-nether-accent rounded-full opacity-0"
          style={{ left: `${10+i*15}%`, animation: `floatUp 8s infinite ease-out ${i*1.5}s` }} />
      ))}
      <style>{`@keyframes floatUp{0%{bottom:-10px;opacity:0}20%{opacity:.3}80%{opacity:.1}100%{bottom:100vh;opacity:0}}`}</style>
    </div>
  )
}
