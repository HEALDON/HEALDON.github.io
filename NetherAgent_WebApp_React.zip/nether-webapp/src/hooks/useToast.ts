import { useCallback, useState } from 'react'

export function useToast() {
  const [toast, setToast] = useState<{msg:string;type?:string} | null>(null)
  const show = useCallback((msg: string, type = '') => {
    setToast({ msg, type })
    setTimeout(() => setToast(null), 2500)
  }, [])
  return { toast, show }
}
