// ربات تلگرام به‌عنوان backend استفاده می‌شه
// آدرس هاست ربات رو اینجا تنظیم کن
export const API_BASE = 'https://healdon.ir';
