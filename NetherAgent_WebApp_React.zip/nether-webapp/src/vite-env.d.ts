/// <reference types="vite/client" />

interface Window {
  Telegram?: {
    WebApp?: {
      initData: string
      expand(): void
      setHeaderColor(color: string): void
      setBackgroundColor(color: string): void
      HapticFeedback?: {
        impactOccurred(style: string): void
        notificationOccurred(type: string): void
      }
    }
  }
}
