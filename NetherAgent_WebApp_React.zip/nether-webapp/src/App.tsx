import { useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useAppStore } from './store'
import { api } from './services/api'
import { MainLayout } from './layouts/MainLayout'
import { LoadingScreen } from './components/LoadingScreen'
import { AdScreen } from './components/AdScreen'
import { ErrorScreen } from './components/ErrorScreen'
import { NetherBg } from './components/NetherBg'
import { useToast } from './hooks/useToast'

export default function App() {
  const { view, setView, setSettings } = useAppStore()
  const { toast } = useToast()

  useEffect(() => {
    const initData = window.Telegram?.WebApp?.initData || ''
    if (!initData) { setView('ad'); return }
    ;(async () => {
      try {
        const d = await api.getSettings()
        if (d.error) { setView('ad'); return }
        setSettings(d); setView('app')
      } catch { setView('error') }
    })()
  }, [])

  return (
    <>
      <NetherBg />
      <AnimatePresence mode="wait">
        {view === 'loading' && <motion.div key="load" exit={{opacity:0}}><LoadingScreen /></motion.div>}
        {view === 'error' && <motion.div key="err" initial={{opacity:0}} animate={{opacity:1}}><ErrorScreen /></motion.div>}
        {view === 'ad' && <motion.div key="ad" initial={{opacity:0}} animate={{opacity:1}}><AdScreen /></motion.div>}
        {view === 'app' && <motion.div key="app" initial={{opacity:0}} animate={{opacity:1}}><MainLayout /></motion.div>}
      </AnimatePresence>
      {toast && (
        <div className={`fixed bottom-20 left-1/2 -translate-x-1/2 px-5 py-2.5 rounded-xl text-[13px] z-[100] glass ${toast.type === 'success' ? 'text-nether-success' : toast.type === 'error' ? 'text-nether-danger' : ''}`}>
          {toast.msg}
        </div>
      )}
    </>
  )
}
