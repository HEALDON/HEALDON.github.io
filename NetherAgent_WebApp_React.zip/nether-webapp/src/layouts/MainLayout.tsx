import { useState } from 'react'
import { Routes, Route, useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { LayoutDashboard, Bot, Rss, FileText, Tv, Globe, User, CreditCard } from 'lucide-react'
import { useAppStore } from '@/store'
import { Dashboard } from '@/pages/Dashboard'
import { AISettings } from '@/pages/AISettings'
import { Sources } from '@/pages/Sources'
import { Posts } from '@/pages/Posts'
import { ChannelSettings } from '@/pages/ChannelSettings'
import { RubikaSettings } from '@/pages/RubikaSettings'
import { Profile } from '@/pages/Profile'
import { Subscription } from '@/pages/Subscription'
import { useToast } from '@/hooks/useToast'

const navItems = [
  { path: '/', label: 'داشبورد', icon: LayoutDashboard },
  { path: '/ai', label: 'هوش مصنوعی', icon: Bot },
  { path: '/sources', label: 'منابع', icon: Rss },
  { path: '/posts', label: 'پست‌ها', icon: FileText },
  { path: '/channel', label: 'کانال', icon: Tv },
  { path: '/rubika', label: 'روبیکا', icon: Globe },
  { path: '/profile', label: 'پروفایل', icon: User },
  { path: '/sub', label: 'اشتراک', icon: CreditCard },
]

export function MainLayout() {
  const { settings } = useAppStore()
  const navigate = useNavigate()
  const { show } = useToast()
  const [curPath, setCurPath] = useState(window.location.pathname)

  const onNav = (path: string) => {
    setCurPath(path); navigate(path)
    window.Telegram?.WebApp?.HapticFeedback?.impactOccurred('light')
  }

  const saveSettings = async (form: any) => {
    try {
      const { api } = await import('@/services/api')
      await api.saveSettings(form)
      show('✅ ذخیره شد', 'success')
    } catch { show('❌ خطا', 'error') }
  }

  return (
    <div className="flex flex-col h-screen relative z-10">
      {/* Topbar */}
      <header className="flex items-center justify-between px-4 py-3 glass border-b border-nether-border shrink-0 z-20">
        <div className="flex items-center gap-2">
          <span className="text-xl">🌋</span>
          <span className="text-[15px] font-bold bg-gradient-to-br from-nether-accent to-white bg-clip-text text-transparent">Nether Agent</span>
        </div>
        <div className="flex items-center gap-1.5 text-[11px] text-nether-text-3">
          <span className={`w-1.5 h-1.5 rounded-full ${settings.ai_provider ? 'bg-nether-accent shadow-[0_0_6px_#FF5A24]' : 'bg-nether-text-3'}`} />
          {settings.is_operator ? 'اوپراتور' : 'ادمین'}
        </div>
      </header>

      {/* Content */}
      <main className="flex-1 overflow-y-auto p-4 pb-24">
        <div className="max-w-xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div key={curPath} initial={{opacity:0, y:8}} animate={{opacity:1, y:0}} exit={{opacity:0}} transition={{duration:.25}}>
              <Routes>
                <Route path="/" element={<Dashboard data={settings} onNav={onNav} />} />
                <Route path="/ai" element={<AISettings settings={settings} onSave={saveSettings} show={show} />} />
                <Route path="/sources" element={<Sources show={show} />} />
                <Route path="/posts" element={<Posts show={show} />} />
                <Route path="/channel" element={<ChannelSettings settings={settings} onSave={saveSettings} show={show} />} />
                <Route path="/rubika" element={<RubikaSettings settings={settings} onSave={saveSettings} />} />
                <Route path="/profile" element={<Profile data={settings} />} />
                <Route path="/sub" element={<Subscription />} />
              </Routes>
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Bottom Nav */}
      <nav className="flex glass border-t border-nether-border shrink-0 overflow-x-auto z-20">
        {navItems.map(({ path, label, icon: Icon }) => (
          <button key={path} className={`nav-item ${curPath === path ? 'active' : ''}`} onClick={() => onNav(path)}>
            <Icon size={20} strokeWidth={1.8} />
            <span>{label}</span>
          </button>
        ))}
      </nav>
    </div>
  )
}
