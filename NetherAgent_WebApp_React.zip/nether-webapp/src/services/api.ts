import { API_BASE } from '@/config';

const tg = window.Telegram?.WebApp;
const initData = tg?.initData || '';

export async function apiFetch<T>(endpoint: string, method = 'GET', body?: unknown): Promise<T> {
  const opts: RequestInit = {
    method,
    headers: { 'Content-Type': 'application/json', 'X-Telegram-Init-Data': initData },
  };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(`${API_BASE}${endpoint}`, opts);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

export const api = {
  getSettings: () => apiFetch<any>('/api/settings'),
  saveSettings: (data: any) => apiFetch<any>('/api/settings', 'POST', data),
  getSources: () => apiFetch<{ sources: any[] }>('/api/sources'),
  addSources: (urls: string[]) => apiFetch<{ added: number }>('/api/sources', 'POST', { urls }),
  deleteSource: (id: number) => apiFetch<any>(`/api/sources/${id}`, 'DELETE'),
  deleteWatermark: () => apiFetch<any>('/api/watermark', 'DELETE'),
  getPosts: (status: string) => apiFetch<{ posts: any[] }>(`/api/posts?status=${status}`),
  approvePost: (uid: string) => apiFetch<any>(`/api/posts/${uid}/approve`, 'POST'),
  rejectPost: (uid: string) => apiFetch<any>(`/api/posts/${uid}/reject`, 'POST'),
};
