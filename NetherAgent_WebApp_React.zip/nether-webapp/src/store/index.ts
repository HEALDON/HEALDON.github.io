import { create } from 'zustand';

interface AppStore {
  view: 'loading' | 'app' | 'ad' | 'error';
  settings: Record<string, any>;
  setView: (v: AppStore['view']) => void;
  setSettings: (s: Record<string, any>) => void;
}

export const useAppStore = create<AppStore>((set) => ({
  view: 'loading',
  settings: {},
  setView: (view) => set({ view }),
  setSettings: (settings) => set({ settings }),
}));
