import { useState, useEffect, useCallback } from 'react'
import { api } from '@/services/api'

export function Posts({ show }: { show: (m: string, t?: string) => void }) {
  const [tab, setTab] = useState('pending')
  const [posts, setPosts] = useState<any[]>([])

  const load = useCallback(async () => { try { const d = await api.getPosts(tab); setPosts(d.posts || []) } catch {} }, [tab])
  useEffect(() => { load() }, [load])

  const approve = async (uid: string) => { const d = await api.approvePost(uid); show(d.success ? 'منتشر شد' : 'خطا', d.success ? 'success' : 'error'); load() }
  const reject = async (uid: string) => { await api.rejectPost(uid); show('رد شد', 'success'); load() }

  return (
    <div>
      <div className="flex gap-1.5 mb-3 overflow-x-auto">
        <div className={`tab ${tab==='pending'?'active':''}`} onClick={() => setTab('pending')}>⏳ در انتظار</div>
        <div className={`tab ${tab==='published'?'active':''}`} onClick={() => setTab('published')}>✅ منتشرشده</div>
        <div className={`tab ${tab==='scheduled'?'active':''}`} onClick={() => setTab('scheduled')}>📅 زمان‌بندی</div>
      </div>
      {posts.length === 0 ? <div className="text-center py-8 text-nether-text-3"><div className="text-3xl mb-2 opacity-50">📋</div><div className="text-[13px]">هیچ پستی وجود ندارد</div></div> :
        posts.map(p => (
          <div key={p.uid} className="card mb-2.5">
            <div className="flex justify-between items-center mb-2"><span className="text-[10px] text-nether-text-3 font-mono">{p.uid}</span><span className="text-[11px] px-2 py-0.5 rounded bg-nether-accent/12 text-nether-accent">⭐{p.overall_score?.toFixed(1)}</span></div>
            <div className="text-[13px] text-nether-text-2 leading-relaxed max-h-[120px] overflow-hidden">{p.caption}</div>
            {tab === 'pending' && <div className="flex gap-2 mt-2.5">
              <button className="btn btn-primary text-xs py-2 flex-1" onClick={() => approve(p.uid)}>✅ تأیید</button>
              <button className="btn btn-danger text-xs py-2 flex-1" onClick={() => reject(p.uid)}>❌ رد</button>
            </div>}
          </div>
        ))}
    </div>
  )
}
