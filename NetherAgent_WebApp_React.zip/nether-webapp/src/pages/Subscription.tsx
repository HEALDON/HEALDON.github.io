export function Subscription() {
  return (
    <div>
      <div className="card text-center mb-3">
        <div className="text-lg font-bold text-nether-accent mb-1">ماهانه</div>
        <div className="text-2xl font-bold my-2">۹۰٬۰۰۰ تومان</div>
        <div className="text-xs text-nether-text-3">در ماه</div>
        <ul className="text-right text-xs text-nether-text-2 leading-loose my-3">
          <li className="pr-4 relative"><span className="absolute right-0 text-nether-accent">✓</span>هوش مصنوعی Agentic</li>
          <li className="pr-4 relative"><span className="absolute right-0 text-nether-accent">✓</span>منابع نامحدود (RSS، Reddit، Website)</li>
          <li className="pr-4 relative"><span className="absolute right-0 text-nether-accent">✓</span>آینه‌ی روبیکا</li>
          <li className="pr-4 relative"><span className="absolute right-0 text-nether-accent">✓</span>واترمارک خودکار</li>
          <li className="pr-4 relative"><span className="absolute right-0 text-nether-accent">✓</span>ماد Modrinth و mcpedl</li>
          <li className="pr-4 relative"><span className="absolute right-0 text-nether-accent">✓</span>یادگیری از بازخورد</li>
          <li className="pr-4 relative"><span className="absolute right-0 text-nether-accent">✓</span>پشتیبانی اختصاصی</li>
        </ul>
        <a href="https://t.me/NetherAgentBot" className="btn btn-primary">📱 خرید اشتراک</a>
      </div>
    </div>
  )
}
