import { useState, useEffect, useCallback } from 'react'
import { api } from '@/services/api'

export function Sources({ show }: { show: (m: string, t?: string) => void }) {
  const [list, setList] = useState<any[]>([])
  const [text, setText] = useState('')

  const load = useCallback(async () => { try { const d = await api.getSources(); setList(d.sources || []) } catch {} }, [])
  useEffect(() => { load() }, [load])

  const add = async () => {
    const urls = text.split('\n').map(l => l.trim()).filter(l => l.startsWith('https://'))
    if (!urls.length) return show('لینک‌ها باید با https:// شروع بشن', 'error')
    const d = await api.addSources(urls); show(`${d.added} منبع اضافه شد`, 'success'); setText(''); load()
  }
  const del = async (id: number) => { await api.deleteSource(id); show('حذف شد', 'success'); load() }

  return (
    <div>
      <div className="card mb-3">
        <div className="flex items-center gap-2 mb-3"><span>📡</span><span className="text-[13px] font-semibold flex-1">افزودن منابع</span></div>
        <p className="text-[11px] text-nether-text-3 mb-2">هر لینک در یک خط — با https://</p>
        <textarea className="field" rows={5} placeholder={'https://feeds.ign.com/ign/all\nhttps://reddit.com/r/gaming\nhttps://mcpedl.com/'} value={text} onChange={e => setText(e.target.value)} />
        <button className="btn btn-ghost mt-2" onClick={add}>➕ افزودن</button>
      </div>
      <div className="card">
        <div className="flex items-center gap-2 mb-3"><span>📋</span><span className="text-[13px] font-semibold flex-1">منابع فعلی</span></div>
        {list.length === 0 ? <div className="text-center py-8 text-nether-text-3"><div className="text-3xl mb-2 opacity-50">📡</div><div className="text-[13px]">هیچ منبعی اضافه نشده</div></div> :
          list.map(s => (
            <div key={s.id} className="flex items-center gap-2.5 p-2.5 bg-nether-bg rounded-xl mb-1.5 border border-transparent transition-all hover:border-nether-border">
              <span className="text-[9px] px-2 py-0.5 rounded bg-nether-accent/12 text-nether-accent whitespace-nowrap">{s.source_type}</span>
              <span className="flex-1 text-[11px] text-nether-text-2 overflow-hidden text-ellipsis whitespace-nowrap">{s.url}</span>
              <span className="text-nether-text-3 cursor-pointer text-sm px-1" onClick={() => del(s.id)}>✕</span>
            </div>
          ))}
      </div>
    </div>
  )
}
