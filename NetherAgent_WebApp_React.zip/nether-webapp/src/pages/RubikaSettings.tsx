import { useState, useEffect } from 'react'

interface Props { settings: any; onSave: (f: any) => void }

export function RubikaSettings({ settings, onSave }: Props) {
  const [form, setForm] = useState(settings)
  useEffect(() => setForm(settings), [settings])
  const set = (k: string, v: any) => setForm((f: any) => ({ ...f, [k]: v }))

  return (
    <div>
      <div className="card mb-3 flex justify-between items-center"><div className="flex items-center gap-2"><span>🌐</span><span className="text-[13px] font-semibold">اتصال به روبیکا</span></div>
        <label className="toggle"><input type="checkbox" checked={form.rubika_enabled || false} onChange={e => set('rubika_enabled', e.target.checked)} /><span className="toggle-slider" /></label></div>
      <div className="card mb-3"><div className="flex items-center gap-2 mb-3"><span>🔑</span><span className="text-[13px] font-semibold flex-1">توکن ربات روبیکا</span></div>
        <input type="password" className="field" placeholder="توکن" value={form.rubika_token || ''} onChange={e => set('rubika_token', e.target.value)} /></div>
      <div className="card mb-3"><div className="flex items-center gap-2 mb-3"><span>🆔</span><span className="text-[13px] font-semibold flex-1">آیدی ادمین روبیکا</span></div>
        <input type="text" className="field" placeholder="@username" value={form.rubika_admin_id || ''} onChange={e => set('rubika_admin_id', e.target.value)} /></div>
      <div className="card mb-3"><div className="flex items-center gap-2 mb-3"><span>📺</span><span className="text-[13px] font-semibold flex-1">کانال روبیکا</span></div>
        <input type="text" className="field" placeholder="@channel" value={form.rubika_channel_id || ''} onChange={e => set('rubika_channel_id', e.target.value)} /></div>
      <button className="btn btn-primary" onClick={() => onSave(form)}>💾 ذخیره</button>
    </div>
  )
}
