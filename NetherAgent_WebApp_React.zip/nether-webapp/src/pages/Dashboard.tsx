interface DashboardProps { data: any; onNav: (p: string) => void }

export function Dashboard({ data, onNav }: DashboardProps) {
  return (
    <div>
      <div className="grid grid-cols-2 gap-2.5 mb-3">
        <div className="stat-card"><div className="stat-val">{data.pending_count ?? 0}</div><div className="stat-label">پست در انتظار</div></div>
        <div className="stat-card" style={{'--tw-text-opacity':1} as any}><div className="stat-val" style={{color:'#00B894'}}>{data.published_count ?? 0}</div><div className="stat-label">پست منتشرشده</div></div>
        <div className="stat-card"><div className="stat-val" style={{color:'#2AB8D6'}}>{data.sources_count ?? 0}</div><div className="stat-label">منابع فعال</div></div>
        <div className="stat-card"><div className="stat-val">{data.collection_interval ?? 30}m</div><div className="stat-label">فاصله جمع‌آوری</div></div>
      </div>
      <div className="card mb-3">
        <div className="flex items-center gap-2 mb-3"><span className="text-base">🤖</span><span className="text-[13px] font-semibold flex-1">وضعیت ایجنت</span></div>
        <div className="flex justify-between items-center mb-2.5"><span className="text-[13px] text-nether-text-2">اتوپست</span><span className="text-[13px]" style={{color:data.autopost_enabled?'#00B894':'#808080'}}>{data.autopost_enabled ? '✅ فعال' : '❌ غیرفعال'}</span></div>
        <div className="flex justify-between items-center mb-2.5"><span className="text-[13px] text-nether-text-2">جمع‌آوری</span><span className="text-[13px] text-nether-text-3">—</span></div>
        <div className="flex justify-between items-center"><span className="text-[13px] text-nether-text-2">Provider</span><span className="text-[13px] text-nether-accent">{data.ai_provider || '—'}</span></div>
      </div>
      <div className="card cursor-pointer" onClick={() => onNav('/posts')}>
        <div className="flex items-center gap-2 mb-1"><span className="text-base">📋</span><span className="text-[13px] font-semibold flex-1">پست‌های در انتظار</span>{data.pending_count > 0 && <span className="text-[10px] px-2 py-0.5 rounded-md bg-nether-accent/15 text-nether-accent">{data.pending_count}</span>}</div>
        <p className="text-[12px] text-nether-text-3">برای مرور و تأیید پست‌ها کلیک کنید</p>
      </div>
    </div>
  )
}
