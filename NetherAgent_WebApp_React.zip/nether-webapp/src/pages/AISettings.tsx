import { useState, useEffect } from 'react'

interface Props { settings: any; onSave: (f: any) => void; show: (m: string, t?: string) => void }

export function AISettings({ settings, onSave, show }: Props) {
  const [form, setForm] = useState(settings)
  useEffect(() => setForm(settings), [settings])
  const set = (k: string, v: any) => setForm((f: any) => ({ ...f, [k]: v }))

  return (
    <div>
      <div className="card mb-3">
        <div className="flex items-center gap-2 mb-3"><span>🤖</span><span className="text-[13px] font-semibold flex-1">Provider</span></div>
        <select className="field" value={form.ai_provider || ''} onChange={e => set('ai_provider', e.target.value)}>
          <option value="openrouter">OpenRouter (رایگان)</option><option value="gemini">Gemini (رایگان)</option>
          <option value="deepseek">DeepSeek</option><option value="openmodel">OpenModel</option>
        </select>
      </div>
      <div className="card mb-3">
        <div className="flex items-center gap-2 mb-3"><span>🔑</span><span className="text-[13px] font-semibold flex-1">API Key</span></div>
        <input type="password" className="field" placeholder="کلید API" value={form.ai_api_key || ''} onChange={e => set('ai_api_key', e.target.value)} />
        <p className="text-[11px] text-nether-text-3 mt-1.5">{form.ai_api_key ? '✅ تنظیم شده' : '—'}</p>
      </div>
      <div className="card mb-3">
        <div className="flex items-center gap-2 mb-3"><span>🧠</span><span className="text-[13px] font-semibold flex-1">مدل</span></div>
        <input type="text" className="field" placeholder="نام مدل" value={form.ai_model || ''} onChange={e => set('ai_model', e.target.value)} />
        <p className="text-[11px] text-nether-text-3 mt-1.5">مثال: google/gemma-2-9b-it:free</p>
      </div>
      <div className="card mb-3">
        <div className="flex items-center gap-2 mb-3"><span>✍️</span><span className="text-[13px] font-semibold flex-1">امضا</span></div>
        <textarea className="field" rows={2} placeholder="🌋 > @MyChannel" value={form.signature || ''} onChange={e => set('signature', e.target.value)} />
      </div>
      <button className="btn btn-primary" onClick={() => onSave(form)}>💾 ذخیره</button>
    </div>
  )
}
