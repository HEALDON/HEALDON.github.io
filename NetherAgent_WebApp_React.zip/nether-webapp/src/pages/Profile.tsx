export function Profile({ data }: { data: any }) {
  return (
    <div>
      <div className="card text-center mb-3">
        <div className="text-4xl mb-2">👤</div>
        <h3 className="text-base font-semibold">{data.full_name || 'کاربر'}</h3>
        <p className="text-[11px] text-nether-text-3">{data.is_operator ? 'اوپراتور اصلی' : 'ادمین'}</p>
      </div>
      <div className="card mb-3"><div className="flex items-center gap-2 mb-3"><span>📅</span><span className="text-[13px] font-semibold flex-1">اشتراک</span></div>
        <p className="text-[13px] text-nether-text-2">وضعیت: {data.subscription_active ? '✅ فعال' : '❌ منقضی'}</p>
        {data.subscription_expires && <p className="text-[11px] text-nether-text-3 mt-1">انقضا: {data.subscription_expires}</p>}</div>
      <div className="card"><div className="flex items-center gap-2 mb-3"><span>📊</span><span className="text-[13px] font-semibold flex-1">آمار</span></div>
        <div className="flex justify-between mb-1.5"><span className="text-xs text-nether-text-3">پست‌های منتشرشده</span><span className="text-xs">{data.published_count || 0}</span></div>
        <div className="flex justify-between mb-1.5"><span className="text-xs text-nether-text-3">منابع فعال</span><span className="text-xs">{data.sources_count || 0}</span></div>
        <div className="flex justify-between"><span className="text-xs text-nether-text-3">Provider</span><span className="text-xs text-nether-accent">{data.ai_provider || '—'}</span></div></div>
    </div>
  )
}
