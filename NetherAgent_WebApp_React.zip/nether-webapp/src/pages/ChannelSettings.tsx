import { useState, useEffect } from 'react'
import { api } from '@/services/api'

interface Props { settings: any; onSave: (f: any) => void; show: (m: string, t?: string) => void }

export function ChannelSettings({ settings, onSave, show }: Props) {
  const [form, setForm] = useState(settings)
  useEffect(() => setForm(settings), [settings])
  const set = (k: string, v: any) => setForm((f: any) => ({ ...f, [k]: v }))

  const rmWM = async () => { await api.deleteWatermark(); show('واترمارک حذف شد', 'success') }

  return (
    <div>
      <div className="card mb-3"><div className="flex items-center gap-2 mb-3"><span>📺</span><span className="text-[13px] font-semibold flex-1">کانال تلگرام</span></div>
        <input type="text" className="field" placeholder="@MyChannel" value={form.channel_id || ''} onChange={e => set('channel_id', e.target.value)} /></div>
      <div className="card mb-3 flex justify-between items-center"><div className="flex items-center gap-2"><span>🔄</span><span className="text-[13px] font-semibold">اتوپست</span></div>
        <label className="toggle"><input type="checkbox" checked={form.autopost_enabled || false} onChange={e => set('autopost_enabled', e.target.checked)} /><span className="toggle-slider" /></label></div>
      <div className="card mb-3"><div className="flex items-center gap-2 mb-3"><span>⏱</span><span className="text-[13px] font-semibold flex-1">فاصله جمع‌آوری</span></div>
        <select className="field" value={form.collection_interval || 30} onChange={e => set('collection_interval', parseInt(e.target.value))}>
          <option value={5}>۵ دقیقه</option><option value={10}>۱۰ دقیقه</option><option value={15}>۱۵ دقیقه</option><option value={30}>۳۰ دقیقه</option><option value={60}>۶۰ دقیقه</option></select></div>
      <div className="card mb-3"><div className="flex items-center gap-2 mb-3"><span>🖼</span><span className="text-[13px] font-semibold flex-1">واترمارک</span></div>
        <p className="text-[11px] text-nether-text-3">{form.watermark_path ? '✅ تنظیم شده' : '❌ تنظیم نشده'}</p>
        <p className="text-[11px] text-nether-text-3 mt-1">برای آپلود واترمارک، در چت ربات عکس رو بفرست.</p>
        {form.watermark_path && <button className="btn btn-danger text-xs py-2 mt-2" style={{width:'auto'}} onClick={rmWM}>🗑 حذف</button>}</div>
      <button className="btn btn-primary" onClick={() => onSave(form)}>💾 ذخیره</button>
    </div>
  )
}
