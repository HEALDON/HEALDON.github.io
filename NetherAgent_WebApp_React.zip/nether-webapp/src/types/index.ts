export interface UserSettings {
  is_operator: boolean;
  ai_provider: string;
  ai_api_key: string;
  ai_model: string;
  signature: string;
  channel_id: string;
  autopost_enabled: boolean;
  collection_interval: number;
  watermark_path: string | null;
  rubika_enabled: boolean;
  rubika_token: string;
  rubika_admin_id: string;
  rubika_channel_id: string;
  full_name?: string;
  subscription_active?: boolean;
  subscription_expires?: string;
  pending_count?: number;
  published_count?: number;
  sources_count?: number;
}

export interface Source {
  id: number;
  url: string;
  source_type: string;
  name: string;
  is_active: boolean;
}

export interface Post {
  uid: string;
  caption: string;
  media_url: string | null;
  content_type: string;
  overall_score: number;
  status: string;
  published_at: string | null;
  ai_reasoning: string | null;
  source_links: string[];
}

export interface ApiResponse<T> {
  data?: T;
  error?: string;
}
