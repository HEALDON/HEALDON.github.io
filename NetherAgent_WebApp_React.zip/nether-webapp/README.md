# Nether Agent — Web Mini App

## Setup

```bash
npm install
npm run dev
```

## Build for GitHub Pages

```bash
npm run build
```

The `dist/` folder is ready to deploy.

## API Configuration

Edit `src/config/index.ts`:

```typescript
export const API_BASE = 'https://healdon.ir';
```

## Deploy to GitHub Pages

```bash
npm run deploy
```

Or manually copy `dist/` to your GitHub Pages repo.
