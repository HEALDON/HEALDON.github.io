/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        nether: {
          bg: '#080808', surface: '#111111', card: '#181818',
          elevated: '#202020', border: 'rgba(255,80,40,.18)',
          accent: '#FF5A24', 'accent-dark': '#C43D20', cyan: '#2AB8D6',
          text: '#FFFFFF', 'text-2': '#C8C8C8', 'text-3': '#808080',
          danger: '#DC143C', success: '#00B894',
        }
      },
      borderRadius: { '2xl': '18px' },
      fontFamily: { sans: ['Inter', '-apple-system', 'Segoe UI', 'Tahoma', 'sans-serif'] },
    }
  },
  plugins: []
}
